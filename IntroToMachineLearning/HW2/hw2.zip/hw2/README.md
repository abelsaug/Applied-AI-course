Homework 2: Building classifiers
UIC CS 412, Spring 2018

You will need the same python 3.6 environment as in your Homework 1. Activate the environment:

elena-macbook:cs412-hw elena$ source activate cs412   #omit the source part on windows

Change to homework directory:

(cs412) elena-macbook:cs412-hw elena$ cd hw2

Start the Jupyter notebook:

(cs412) elena-macbook:hw2 elena$ jupyter notebook &

This should open a notebook in your web browser and display the contents of the current directory. Select hw2.ipynb, and follow the instructions in the notebook.



